package org.sonar.samples.java;

import org.sonar.api.Plugin;
import org.sonar.samples.java.checks.CustomRuleRepository;

public class TypeCheckingPlugin implements Plugin {

  @Override
  public void define(Context context) {
    context.addExtension(CustomRuleRepository.class);
  }
}
